package com.example.organify_backend.model.enumerate;


import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role 
{
    ADMIN,
    CUSTOMER
}